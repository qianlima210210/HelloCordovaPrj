cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/com.qianli.mytoast/www/MyToast.js",
        "id": "com.qianli.mytoast.MyToast",
        "pluginId": "com.qianli.mytoast",
        "clobbers": [
            "cordova.plugins.MyToast"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.3.4",
    "cordova-plugin-geolocation": "4.1.0",
    "com.qianli.mytoast": "1.0.0"
}
// BOTTOM OF METADATA
});